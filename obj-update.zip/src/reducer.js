import { createSlice } from "@reduxjs/toolkit";

const  objslice = createSlice({
    name:"Obj",
    // initialState: {"id":1,"name":"raju"},
    initialState:{name:"mohit",location:"India",city:{
        area:"CG ROAD",
        pin:12345
    }},
    reducers:{
        change:(state,action)=>{
              console.log(state)
              console.log(action.payload)
                  
              if(action.payload)
              {
                 return {...state,city:{...state.city,pin:9999}}
              }
            //   else
            //   {
            //     return {...state}
            //   }
        }
    }
       
      
    
})


export default objslice.reducer;
export const {change} = objslice.actions;