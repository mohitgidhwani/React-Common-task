import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { change } from './reducer'

function Home() {

    const dispatch = useDispatch()

    

    const data  = useSelector((state) => {
        // console.log(state.objdata)

        // console.log(action)
        return state.objdata
    })

    const fun = ()=>{
        dispatch(change({pin:55555}))
    }

   
    return (
        <>
            <h1>Array Update</h1>
            <div className='container-fluid'>
                <div className='row justify-content-center'>
                    <div className='col-xl-6'>
                        <table className='table'>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Country</th>
                                    <th>Area</th>
                                    <th>Pincode</th>
                                </tr>
                            </thead>
                            <tbody>
                               <tr>
                                  <td>{data.name}</td>
                                  <td>{data.location}</td>
                                  <td>{data.city.area}</td>
                                  <td>{data.city.pin}</td>
                               </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <button className='btn btn-info' onClick={fun}>Change</button>
        </>
    )
}


export default Home