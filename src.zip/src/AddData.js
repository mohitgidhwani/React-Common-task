import React, { useState } from 'react'

function AddData({adddata}) {
    const [array,setArray] = useState("")
  return (
   <>
     <input type='text' value={array} onChange={(e)=>{setArray(e.target.value)}}></input>
     <button onClick={()=>{
          adddata(array)
     }}>Add</button>
   </>
  )
}

export default AddData