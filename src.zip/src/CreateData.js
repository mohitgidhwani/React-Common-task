// import React, { useState } from 'react'
// import AddData from './AddData';


// function TodoData({array,edit,deleteid})
// {
//     return(
//         <>
//             {array.map((value)=>{
//                     return(
//                         <>
//                        <li key={value.id}>
//                            <Buttons arraydata={value} onchange={edit} ondelete={deleteid}></Buttons>
//                        </li>
                           
//                         </>
//                     )
//             })}
//         </>
//     )
// }

// function Buttons({arraydata,onchange,ondelete}) {

//     const [show,setShow] = useState(true)


//     let btn;

//     if(show)
//     {
//            btn = <>
//             {arraydata.name} {" "}
//             <button onClick={()=>{setShow(false)}}>Edit</button>
//            </>
//     }
//     else
//     {
//         btn =  <>
//         <input type='text' value= {arraydata.name} onChange={(e)=>{
//             onchange(
//                { ...arraydata,
//                 name:e.target.value}
//             )
//         }}></input>
//         <button onClick={()=>{setShow(true)}}>Save</button>
//         </>
//     }
//   return (
//    <>
        
          
//         {btn}
//        <button onClick={()=>{
//           ondelete(arraydata.id)
//         //   console.log(arraydata.id)
//        }}>Delete</button>
//    </>
//   )
// }

// export default TodoData