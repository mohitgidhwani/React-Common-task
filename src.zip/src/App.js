import logo from './logo.svg';
import './App.css';
import TodoData from './CreateData';
import AddData from './AddData';
import { act, useReducer, useState } from 'react';
import ReducerDsiplay from './ReducerDsiplay';

const data = [
  {"id":1,"name":"Mohit"},
  {"id":2,"name":"Raju"}
]
// let index = 3
function App() { 

//  const [array,setArray] = useState(data)

//   const handleadd = (name)=>{
//     // console.log(name)
//       setArray(
//         [...array,
//          {"id":index++,"name":name}
//         ]
//       ) 
//   }

  

//   const handleEdit = (data)=>{
//     // console.log(adata)

//     setArray(array.map((value)=>{
//             if(value.id ==  data.id)
//             {
//               return data
//             }
//             else
//             {
//               return value
//             }
//     }))
//   }

//   const handledelete = (obj)=>{
//     console.log(obj)
//     setArray(array.filter((v)=>{
//          return v.id !== obj
//     }))
//   }


// const handleadd = (text)=>{
//    console.log(text)
// }

let  val=3;

const fun = (state,action)=>{

  console.log(state,action)
     switch(action.type)
     {
        case "inc" : return [...data,{"id":val++,"name":state.name}]
     }
}

const [state,dispatch] = useReducer(fun , val)




  return (
    <div className="App">
       <h1>Todo App</h1>
       {/* <AddData adddata={handleadd}></AddData>
       <TodoData array={array} edit={handleEdit} deleteid={handledelete}></TodoData> */}
       {/* <ReducerDsiplay></ReducerDsiplay> */}
       {/* <TodoData array={data}></TodoData> */}
       <ReducerDsiplay data={data} onadd={()=>{dispatch({type:"inc"})}}></ReducerDsiplay>

    </div>
  );
}

export default App;
