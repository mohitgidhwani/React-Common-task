import React, { useState } from 'react'
import { useReducer } from 'react';

function ReducerDsiplay({data,onadd}) {
    const [txt,setTxt] = useState("")
  return (
   <>
     <input type='text' value={txt} onChange={(e)=>{setTxt(e.target.value)}}></input> <button onClick={()=>{
              onadd(txt)
     }}>Add</button>

     {data.map((value)=>{
                return(
                    <>
                    <li>
                         <Btn array={value}></Btn>
                         </li>
                   
                    </>
                )
     })}
   </>
  )
}






function Btn({ array }) {
    function reducer(show, action) 
    {
        switch (action.type) {
            case 'change':
                return !show; 
            default:
                return show;
        }
    }


       

    const [show, dispatch] = useReducer(reducer, true);

    // console.log(show)
    let button;

    if (show) {
        
        button = <>
          <span>{array.name}</span>
         <button onClick={() => dispatch({ type: 'change' })}>Edit</button>
         
        </>
       
    } else {
        
        button = 
        <>
          <input type='text' value={array.name}/>
         <button onClick={() => dispatch({ type: 'change' })}>Save</button>
        </>
  
    }
       

    return (
        <>
           
            {button}
            <button>Delete</button>
        </>
    );
}

// export default Btn;

export default ReducerDsiplay